# Matrik 1.2.0 - Giảm lag cho Fabric 1.21.11 (Zalith / điện thoại)

## Mod làm gì
Mỗi giây mod đọc FPS thật. FPS thấp liên tục thì tự hạ dần: render distance, simulation distance,
khoảng cách entity, particles (tối đa 8 mức). FPS ổn định đủ lâu thì tự nâng lại.
Thiết lập gốc của bạn được nhớ và trả lại khi thoát thế giới / tắt game.
Nếu bạn tự chỉnh trong Options thì mod coi đó là giá trị gốc mới.

## Chế độ (mới ở 1.2.0)
- **Nhẹ:** phản ứng chậm, ít can thiệp.
- **Thường:** mặc định.
- **Máy yếu:** vào thế giới là giảm mạnh ngay (render mỗi mức -2 chunk, tắt mây, tắt bóng entity,
  particles giảm, entity và simulation distance thấp), và chỉ nâng lại khi FPS ổn định 40 giây.
- **Cắt particle:** khi đang giảm tải, bỏ bớt particle ở xa (particle sát người luôn giữ).
  Phần này dùng mixin có `require=0`: nếu tên method không khớp thì tự bỏ qua, không crash.

## Lệnh trong game
- `/matrik mode nhe|thuong|mayyeu` đổi chế độ
- `/matrik` mở màn hình cài đặt
- `/matrik status` xem FPS, mức hiện tại, GPU
- `/matrik auto true|false` bật/tắt tự động
- `/matrik target 45` đặt FPS mục tiêu
- `/matrik preset low|balanced|high` áp preset nhanh

## Build (không cần máy tính)
1. Tạo repo GitHub, upload toàn bộ nội dung thư mục này.
2. Vào tab Actions, chạy "Build Matrik".
3. Tải artifact `matrik-jar`, lấy file `matrik-1.2.0.jar` (không phải `-sources`).
4. Chép vào thư mục mods của phiên bản Fabric 1.21.11 trong Zalith, cùng với Fabric API.

Nếu Gradle báo không tìm thấy phiên bản nào, mở `gradle.properties` và đổi sang số mới nhất
tại https://fabricmc.net/develop

## Mẹo thêm cho Zalith
- Chọn renderer khác trong Zalith nếu FPS vẫn thấp (mỗi GPU hợp một renderer khác nhau).
- Giảm RAM cấp cho game nếu máy hay bị kill app; cấp quá nhiều dễ gây giật khi dọn rác bộ nhớ.
