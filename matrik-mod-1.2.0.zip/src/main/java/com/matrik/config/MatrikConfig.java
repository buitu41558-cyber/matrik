package com.matrik.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParseException;
import com.matrik.MatrikMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

public class MatrikConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** Bật bộ tự động giảm/tăng chất lượng theo FPS. */
    public boolean adaptiveEnabled = true;
    /** FPS mục tiêu (30/45/60/90/120...). */
    public int targetFps = 60;
    /** Giới hạn FPS tối đa bằng targetFps để máy đỡ nóng. */
    public boolean capFps = true;
    /** Render distance thấp nhất mà bộ tự động được phép hạ xuống. */
    public int minViewDistance = 4;
    public boolean adaptSimulation = true;
    public boolean adaptEntities = true;
    public boolean adaptParticles = true;
    /** Hiện thông báo trên màn hình khi đổi mức. */
    public boolean notifications = false;
    /** 0 = Nhẹ, 1 = Thường, 2 = Máy yếu (giảm mạnh ngay khi vào thế giới). */
    public int aggression = 1;
    /** Bớt và cắt particles ở xa khi đang giảm tải. */
    public boolean particleThrottle = true;

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("matrik.json");
    }

    public static MatrikConfig load() {
        Path p = path();
        if (Files.exists(p)) {
            try (Reader reader = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
                MatrikConfig cfg = GSON.fromJson(reader, MatrikConfig.class);
                if (cfg != null) {
                    cfg.sanitize();
                    return cfg;
                }
            } catch (IOException | JsonParseException e) {
                MatrikMod.LOGGER.warn("[Matrik] Không đọc được config, dùng mặc định: {}", e.toString());
            }
        }
        MatrikConfig def = new MatrikConfig();
        def.save();
        return def;
    }

    public void sanitize() {
        targetFps = Math.max(20, Math.min(240, targetFps));
        minViewDistance = Math.max(2, Math.min(16, minViewDistance));
        aggression = Math.max(0, Math.min(2, aggression));
    }

    public void save() {
        sanitize();
        Path p = path();
        Path tmp = p.resolveSibling("matrik.json.tmp");
        try {
            Files.writeString(tmp, GSON.toJson(this), StandardCharsets.UTF_8);
            Files.move(tmp, p, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            MatrikMod.LOGGER.warn("[Matrik] Không lưu được config: {}", e.toString());
        }
    }
}
