package com.matrik;

import com.matrik.command.MatrikCommand;
import com.matrik.config.MatrikConfig;
import com.matrik.core.HardwareProfiler;
import com.matrik.core.ParticleThrottle;
import com.matrik.core.PerformanceGovernor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MatrikMod implements ClientModInitializer {
    public static final String MOD_ID = "matrik";
    public static final Logger LOGGER = LoggerFactory.getLogger("Matrik");

    public static MatrikConfig CONFIG;
    public static HardwareProfiler PROFILER;
    public static PerformanceGovernor GOVERNOR;
    public static ParticleThrottle PARTICLES;

    @Override
    public void onInitializeClient() {
        CONFIG = MatrikConfig.load();
        PROFILER = new HardwareProfiler();
        GOVERNOR = new PerformanceGovernor();
        PARTICLES = new ParticleThrottle();

        ClientTickEvents.END_CLIENT_TICK.register(GOVERNOR::onClientTick);
        // Trả lại thiết lập gốc của người chơi khi thoát thế giới / tắt game
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> GOVERNOR.restoreUserSettings(client));
        ClientLifecycleEvents.CLIENT_STOPPING.register(GOVERNOR::restoreUserSettings);
        ClientCommandRegistrationCallback.EVENT.register(MatrikCommand::register);

        LOGGER.info("[Matrik] Đã khởi tạo. Gõ /matrik trong game để mở cài đặt.");
    }
}
