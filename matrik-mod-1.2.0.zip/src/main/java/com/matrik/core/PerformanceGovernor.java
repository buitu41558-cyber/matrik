package com.matrik.core;

import com.matrik.MatrikMod;
import com.matrik.config.MatrikConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.text.Text;

import java.util.Objects;
import java.util.function.UnaryOperator;

/**
 * Theo dõi FPS mỗi giây. FPS thấp liên tục -> tăng "mức giảm tải" (level),
 * FPS ổn định đủ lâu -> hạ level dần. Không ghi đè vĩnh viễn thiết lập của người chơi:
 * giá trị gốc được nhớ và trả lại khi thoát thế giới / tắt tính năng / tắt game,
 * còn nếu người chơi tự chỉnh trong Options thì giá trị mới được xem là giá trị gốc.
 */
public final class PerformanceGovernor {
    public static final int MAX_LEVEL = 8;

    private static final double OK_RATIO = 0.95;
    private static final int MIN_UP_WAIT = 20;
    private static final int MAX_UP_WAIT = 240;

    private final Managed<Integer> viewDistance = new Managed<>();
    private final Managed<Integer> simDistance = new Managed<>();
    private final Managed<Double> entityScale = new Managed<>();
    private final Managed<ParticlesMode> particles = new Managed<>();
    private final Managed<Integer> maxFps = new Managed<>();
    private final Managed<CloudRenderMode> clouds = new Managed<>();
    private final Managed<Boolean> shadows = new Managed<>();

    private int level;
    private int effLevel;
    private int tickCounter;
    private int lowStreak;
    private int highStreak;
    private int warmupSeconds;
    private int upWaitSeconds = MIN_UP_WAIT;
    private long lastRelaxMillis;
    private int lastFps;
    private boolean profiled;
    private ClientWorld lastWorld;

    public int getLevel() { return level; }
    /** Mức hiệu dụng (đã cộng thêm bù của chế độ Máy yếu). */
    public int getEffectiveLevel() { return effLevel; }
    public int getLastFps() { return lastFps; }

    public void onClientTick(MinecraftClient client) {
        if (!profiled) {
            profiled = true;
            MatrikMod.PROFILER.profile();
        }
        if (client.world == null || client.player == null) {
            lastWorld = null;
            return;
        }
        if (client.world != lastWorld) {
            lastWorld = client.world;
            resetState();
            MatrikConfig c = MatrikMod.CONFIG;
            warmupSeconds = c.aggression >= 2 ? 5 : 15;
            // Chế độ Máy yếu: giảm mạnh ngay từ đầu, không đợi bị giật trước
            if (c.adaptiveEnabled && c.aggression >= 2) {
                level = 4;
                applyLevel(client.options, c);
            }
        }
        if (++tickCounter < 20) return;
        tickCounter = 0;
        if (client.isPaused()) return;

        MatrikConfig cfg = MatrikMod.CONFIG;
        if (!cfg.adaptiveEnabled) {
            if (level != 0 || viewDistance.isManaging() || maxFps.isManaging()) {
                restoreUserSettings(client);
            }
            return;
        }
        step(client, cfg);
    }

    private void step(MinecraftClient client, MatrikConfig cfg) {
        GameOptions o = client.options;
        applyLevel(o, cfg);

        lastFps = client.getCurrentFps();
        if (warmupSeconds > 0) {
            warmupSeconds--;
            return;
        }

        int userMaxFps = maxFps.user(o.getMaxFps());
        int effTarget = Math.min(cfg.targetFps, userMaxFps);
        boolean potato = cfg.aggression >= 2;
        int lowNeeded = (potato || MatrikMod.PROFILER.isWeakGpu()) ? 2 : 3;
        double lowRatio = potato ? 0.90 : cfg.aggression == 0 ? 0.75 : 0.80;
        int minUpWait = potato ? 40 : MIN_UP_WAIT;
        if (upWaitSeconds < minUpWait) upWaitSeconds = minUpWait;

        if (lastFps < effTarget * lowRatio) {
            lowStreak++;
            highStreak = 0;
        } else if (lastFps >= effTarget * OK_RATIO) {
            highStreak++;
            lowStreak = 0;
        } else {
            lowStreak = 0;
            highStreak = 0;
        }

        long now = System.currentTimeMillis();
        if (lowStreak >= lowNeeded && level < MAX_LEVEL) {
            // Vừa nới lên mà lại tụt FPS -> chờ lâu hơn trước lần nới tiếp theo
            if (now - lastRelaxMillis < 90_000L) {
                upWaitSeconds = Math.min(upWaitSeconds * 2, MAX_UP_WAIT);
            }
            setLevel(client, level + 1);
        } else if (highStreak >= upWaitSeconds && level > 0) {
            lastRelaxMillis = now;
            setLevel(client, level - 1);
        } else if (level == 0 && highStreak >= 60) {
            upWaitSeconds = minUpWait;
        }
    }

    private void setLevel(MinecraftClient client, int newLevel) {
        level = Math.max(0, Math.min(MAX_LEVEL, newLevel));
        lowStreak = 0;
        highStreak = 0;
        applyLevel(client.options, MatrikMod.CONFIG);
        if (MatrikMod.CONFIG.notifications && client.player != null) {
            client.player.sendMessage(Text.literal("Matrik: mức giảm tải " + level + "/" + MAX_LEVEL
                    + " | Render " + client.options.getViewDistance().getValue()), true);
        }
    }

    private void applyLevel(GameOptions o, MatrikConfig cfg) {
        final int lv = level;
        final boolean potato = cfg.aggression >= 2;
        // Máy yếu: mỗi mức hạ 2 chunk và các giới hạn khác bắt đầu sớm hơn 2 mức
        final int ef = lv == 0 ? 0 : lv + (potato ? 2 : 0);
        final int vdStep = potato ? 2 : 1;
        effLevel = ef;

        viewDistance.update(o.getViewDistance(), v ->
                lv == 0 ? v : Math.max(Math.min(v, cfg.minViewDistance), v - vdStep * lv));

        simDistance.update(o.getSimulationDistance(), v -> {
            if (!cfg.adaptSimulation || ef < 3) return v;
            return Math.min(v, ef >= 5 ? 6 : 8);
        });

        entityScale.update(o.getEntityDistanceScaling(), v -> {
            if (!cfg.adaptEntities || ef < 2) return v;
            return Math.min(v, ef >= 5 ? 0.5 : 0.75);
        });

        particles.update(o.getParticles(), p -> {
            if (!cfg.adaptParticles || ef < 4) return p;
            ParticlesMode target = ef >= 6 ? ParticlesMode.MINIMAL : ParticlesMode.DECREASED;
            return p.ordinal() >= target.ordinal() ? p : target;
        });

        clouds.update(o.getCloudRenderMode(), c -> ef >= 3 ? CloudRenderMode.OFF : c);

        shadows.update(o.getEntityShadows(), b -> ef >= 4 ? Boolean.FALSE : b);

        maxFps.update(o.getMaxFps(), v -> cfg.capFps && v > cfg.targetFps ? cfg.targetFps : v);
    }

    /** Trả mọi thiết lập về giá trị gốc của người chơi. */
    public void restoreUserSettings(MinecraftClient client) {
        try {
            GameOptions o = client.options;
            if (o != null) {
                viewDistance.restore(o.getViewDistance());
                simDistance.restore(o.getSimulationDistance());
                entityScale.restore(o.getEntityDistanceScaling());
                particles.restore(o.getParticles());
                clouds.restore(o.getCloudRenderMode());
                shadows.restore(o.getEntityShadows());
                maxFps.restore(o.getMaxFps());
            }
        } catch (Exception e) {
            MatrikMod.LOGGER.warn("[Matrik] Lỗi khi khôi phục thiết lập: {}", e.toString());
        }
        resetState();
    }

    private void resetState() {
        level = 0;
        effLevel = 0;
        lowStreak = 0;
        highStreak = 0;
        upWaitSeconds = MIN_UP_WAIT;
        tickCounter = 0;
    }

    /** Giữ giá trị gốc của người chơi cho một option và phát hiện khi họ tự chỉnh. */
    private static final class Managed<T> {
        private T user;
        private T applied;

        boolean isManaging() { return applied != null; }

        T user(SimpleOption<T> opt) {
            return applied == null ? opt.getValue() : user;
        }

        void update(SimpleOption<T> opt, UnaryOperator<T> transform) {
            T cur = opt.getValue();
            if (applied != null && !Objects.equals(cur, applied)) {
                applied = null; // người chơi tự đổi -> coi giá trị mới là giá trị gốc
            }
            if (applied == null) {
                user = cur;
            }
            T desired = transform.apply(user);
            if (!Objects.equals(desired, cur)) {
                opt.setValue(desired);
                applied = desired;
            } else if (Objects.equals(desired, user)) {
                applied = null;
            }
        }

        void restore(SimpleOption<T> opt) {
            if (applied != null) {
                if (Objects.equals(opt.getValue(), applied)) {
                    opt.setValue(user);
                }
                applied = null;
            }
        }
    }
}
