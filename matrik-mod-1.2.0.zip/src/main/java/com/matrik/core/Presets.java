package com.matrik.core;

import com.matrik.MatrikMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;

/** Bộ thiết lập nhanh: ghi thẳng vào Options của game (làm giá trị gốc mới). */
public final class Presets {
    private Presets() {}

    public static boolean apply(MinecraftClient client, String name) {
        GameOptions o = client.options;
        // Trả giá trị gốc trước để governor không coi giá trị đang bị giảm là "gốc"
        MatrikMod.GOVERNOR.restoreUserSettings(client);

        switch (name) {
            case "low" -> set(o, 6, 5, 0.5, ParticlesMode.DECREASED, CloudRenderMode.OFF, 0, false);
            case "balanced" -> set(o, 8, 6, 0.75, ParticlesMode.DECREASED, CloudRenderMode.FAST, 1, true);
            case "high" -> set(o, 12, 10, 1.0, ParticlesMode.ALL, CloudRenderMode.FANCY, 2, true);
            default -> {
                return false;
            }
        }
        o.write();
        return true;
    }

    private static void set(GameOptions o, int viewDistance, int simDistance, double entityScale,
                            ParticlesMode particles, CloudRenderMode clouds, int biomeBlend, boolean shadows) {
        o.getViewDistance().setValue(viewDistance);
        o.getSimulationDistance().setValue(simDistance);
        o.getEntityDistanceScaling().setValue(entityScale);
        o.getParticles().setValue(particles);
        o.getCloudRenderMode().setValue(clouds);
        o.getBiomeBlendRadius().setValue(biomeBlend);
        o.getEntityShadows().setValue(shadows);
    }
}
