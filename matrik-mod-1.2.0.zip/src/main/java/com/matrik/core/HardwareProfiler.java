package com.matrik.core;

import com.matrik.MatrikMod;
import org.lwjgl.opengl.GL11;

import java.util.Locale;

/** Nhận diện GPU/CPU. Phải gọi trên luồng render (khi đã có OpenGL context). */
public final class HardwareProfiler {
    private String gpuVendor = "Unknown";
    private String gpuRenderer = "Unknown";
    private int cpuCores = 1;
    private boolean weakGpu;

    public void profile() {
        cpuCores = Runtime.getRuntime().availableProcessors();
        try {
            String v = GL11.glGetString(GL11.GL_VENDOR);
            String r = GL11.glGetString(GL11.GL_RENDERER);
            if (v != null) gpuVendor = v;
            if (r != null) gpuRenderer = r;
        } catch (Exception e) {
            MatrikMod.LOGGER.warn("[Matrik] Không đọc được thông tin GPU: {}", e.toString());
        }
        String r = gpuRenderer.toLowerCase(Locale.ROOT);
        weakGpu = r.contains("mali") || r.contains("powervr") || r.contains("videocore")
                || r.contains("llvmpipe") || r.contains("software");

        MatrikMod.LOGGER.info("[Matrik] GPU: {} / {} | CPU: {} nhân | GPU yếu: {}",
                gpuVendor, gpuRenderer, cpuCores, weakGpu);
    }

    public String getGpuRenderer() { return gpuRenderer; }
    public String getGpuVendor() { return gpuVendor; }
    public int getCpuCores() { return cpuCores; }
    public boolean isWeakGpu() { return weakGpu; }
}
