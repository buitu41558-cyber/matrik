package com.matrik.core;

import com.matrik.MatrikMod;
import com.matrik.config.MatrikConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

/** Quyết định bỏ bớt particle khi game đang ở mức giảm tải. */
public final class ParticleThrottle {
    private int counter;

    public boolean shouldDrop(double x, double y, double z) {
        MatrikConfig cfg = MatrikMod.CONFIG;
        if (cfg == null || !cfg.particleThrottle || !cfg.adaptiveEnabled) return false;
        int ef = MatrikMod.GOVERNOR.getEffectiveLevel();
        if (ef <= 0) return false;

        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) return false;

        double dx = x - p.getX();
        double dy = y - p.getY();
        double dz = z - p.getZ();
        double d2 = dx * dx + dy * dy + dz * dz;

        if (d2 < 16.0) return false; // particle sát người (đập block, hit) luôn giữ

        double maxDist = ef >= 6 ? 16.0 : ef >= 3 ? 24.0 : 40.0;
        if (d2 > maxDist * maxDist) return true;

        int keepEvery = ef >= 6 ? 4 : ef >= 4 ? 3 : ef >= 2 ? 2 : 1;
        return keepEvery > 1 && (counter++ % keepEvery) != 0;
    }
}
