package com.matrik.gui;

import com.matrik.MatrikMod;
import com.matrik.config.MatrikConfig;
import com.matrik.core.PerformanceGovernor;
import com.matrik.core.Presets;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public class MatrikSettingsScreen extends Screen {
    private static final int[] FPS_CHOICES = {30, 45, 60, 90, 120};
    private static final int VD_MIN = 2;
    private static final int VD_MAX = 16;

    private final Screen parent;

    public MatrikSettingsScreen(Screen parent) {
        super(Text.literal("Matrik - Giảm lag"));
        this.parent = parent;
    }

    private static final String[] MODE_NAMES = {"Nhẹ", "Thường", "Máy yếu"};

    @Override
    protected void init() {
        final MatrikConfig cfg = MatrikMod.CONFIG;
        final int cx = this.width / 2;
        final int w = 200;
        final int half = 98;
        final int left = cx - w / 2;
        final int right = left + half + 4;
        final int gap = 22;
        int y = 40;

        // Hàng 1: Tự động | Chế độ
        this.addDrawableChild(ButtonWidget.builder(onOff("Tự động", cfg.adaptiveEnabled), b -> {
            cfg.adaptiveEnabled = !cfg.adaptiveEnabled;
            b.setMessage(onOff("Tự động", cfg.adaptiveEnabled));
        }).dimensions(left, y, half, 20).build());
        this.addDrawableChild(ButtonWidget.builder(modeText(cfg.aggression), b -> {
            cfg.aggression = (cfg.aggression + 1) % 3;
            b.setMessage(modeText(cfg.aggression));
        }).dimensions(right, y, half, 20).build());
        y += gap;

        // Hàng 2: FPS mục tiêu | Khóa FPS
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Mục tiêu: " + cfg.targetFps), b -> {
            cfg.targetFps = nextFps(cfg.targetFps);
            b.setMessage(Text.literal("Mục tiêu: " + cfg.targetFps));
        }).dimensions(left, y, half, 20).build());
        this.addDrawableChild(ButtonWidget.builder(onOff("Khóa FPS", cfg.capFps), b -> {
            cfg.capFps = !cfg.capFps;
            b.setMessage(onOff("Khóa FPS", cfg.capFps));
        }).dimensions(right, y, half, 20).build());
        y += gap;

        // Hàng 3: thanh trượt render distance thấp nhất
        this.addDrawableChild(new SliderWidget(left, y, w, 20, vdText(cfg.minViewDistance),
                (cfg.minViewDistance - VD_MIN) / (double) (VD_MAX - VD_MIN)) {
            @Override
            protected void updateMessage() {
                this.setMessage(vdText(toVd(this.value)));
            }

            @Override
            protected void applyValue() {
                cfg.minViewDistance = toVd(this.value);
            }
        });
        y += gap;

        // Hàng 4: Thông báo | Cắt particle
        this.addDrawableChild(ButtonWidget.builder(onOff("Thông báo", cfg.notifications), b -> {
            cfg.notifications = !cfg.notifications;
            b.setMessage(onOff("Thông báo", cfg.notifications));
        }).dimensions(left, y, half, 20).build());
        this.addDrawableChild(ButtonWidget.builder(onOff("Cắt particle", cfg.particleThrottle), b -> {
            cfg.particleThrottle = !cfg.particleThrottle;
            b.setMessage(onOff("Cắt particle", cfg.particleThrottle));
        }).dimensions(right, y, half, 20).build());
        y += gap;

        // Hàng 5: preset
        int bw = 64;
        this.addDrawableChild(presetButton("Thấp", "low", left, y, bw));
        this.addDrawableChild(presetButton("Vừa", "balanced", left + bw + 4, y, bw));
        this.addDrawableChild(presetButton("Cao", "high", left + 2 * (bw + 4), y, bw));
        y += gap;

        // Hàng 6: xong
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Xong"), b -> this.close())
                .dimensions(left, y, w, 20).build());
    }

    private static Text modeText(int mode) {
        return Text.literal("Chế độ: " + MODE_NAMES[Math.max(0, Math.min(2, mode))]);
    }

    private ButtonWidget presetButton(String label, String preset, int x, int y, int width) {
        return ButtonWidget.builder(Text.literal(label), b -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (Presets.apply(mc, preset) && mc.player != null) {
                mc.player.sendMessage(Text.literal("Matrik: đã áp dụng preset " + label), true);
            }
        }).dimensions(x, y, width, 20).build();
    }

    private static Text onOff(String label, boolean value) {
        return Text.literal(label + ": " + (value ? "BẬT" : "TẮT"));
    }

    private static Text vdText(int vd) {
        return Text.literal("Render tối thiểu: " + vd);
    }

    private static int toVd(double sliderValue) {
        return VD_MIN + (int) Math.round(sliderValue * (VD_MAX - VD_MIN));
    }

    private static int nextFps(int current) {
        for (int fps : FPS_CHOICES) {
            if (fps > current) return fps;
        }
        return FPS_CHOICES[0];
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // super.render đã vẽ nền; gọi renderBackground thêm lần nữa sẽ gây crash "blur once per frame"
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 6, 0xFFFFFFFF);

        MinecraftClient mc = MinecraftClient.getInstance();
        Runtime rt = Runtime.getRuntime();
        long usedMb = (rt.totalMemory() - rt.freeMemory()) / 1024 / 1024;
        long maxMb = rt.maxMemory() / 1024 / 1024;
        String line1 = "FPS " + mc.getCurrentFps()
                + " | Mức " + MatrikMod.GOVERNOR.getLevel() + "/" + PerformanceGovernor.MAX_LEVEL
                + " | RAM " + usedMb + "/" + maxMb + "MB";
        context.drawCenteredTextWithShadow(this.textRenderer, line1, this.width / 2, 17, 0xFFAAAAAA);
        context.drawCenteredTextWithShadow(this.textRenderer, "GPU: " + MatrikMod.PROFILER.getGpuRenderer(),
                this.width / 2, 27, 0xFFAAAAAA);
    }

    @Override
    public void removed() {
        MatrikMod.CONFIG.save();
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(this.parent);
        }
    }
}
