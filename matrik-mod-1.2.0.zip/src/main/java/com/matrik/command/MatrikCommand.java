package com.matrik.command;

import com.matrik.MatrikMod;
import com.matrik.config.MatrikConfig;
import com.matrik.core.PerformanceGovernor;
import com.matrik.core.Presets;
import com.matrik.gui.MatrikSettingsScreen;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.text.Text;

/** /matrik, /matrik status, /matrik auto <true|false>, /matrik target <fps>, /matrik preset <low|balanced|high>, /matrik mode <nhe|thuong|mayyeu> */
public final class MatrikCommand {
    private MatrikCommand() {}

    public static void register(CommandDispatcher<FabricClientCommandSource> dispatcher, CommandRegistryAccess access) {
        dispatcher.register(ClientCommandManager.literal("matrik")
                .executes(ctx -> {
                    MinecraftClient mc = ctx.getSource().getClient();
                    // Chat đang đóng lại, nên mở màn hình ở tick sau
                    mc.send(() -> mc.setScreen(new MatrikSettingsScreen(null)));
                    return 1;
                })
                .then(ClientCommandManager.literal("status").executes(ctx -> {
                    MatrikConfig cfg = MatrikMod.CONFIG;
                    MinecraftClient mc = ctx.getSource().getClient();
                    ctx.getSource().sendFeedback(Text.literal(
                            "Matrik | auto: " + (cfg.adaptiveEnabled ? "BẬT" : "TẮT")
                                    + " | mục tiêu: " + cfg.targetFps + " FPS"
                                    + " | FPS hiện tại: " + mc.getCurrentFps()
                                    + " | mức: " + MatrikMod.GOVERNOR.getLevel() + "/" + PerformanceGovernor.MAX_LEVEL
                                    + " | render: " + mc.options.getViewDistance().getValue()
                                    + " | GPU: " + MatrikMod.PROFILER.getGpuRenderer()));
                    return 1;
                }))
                .then(ClientCommandManager.literal("auto")
                        .then(ClientCommandManager.argument("bat", BoolArgumentType.bool()).executes(ctx -> {
                            boolean on = BoolArgumentType.getBool(ctx, "bat");
                            MatrikMod.CONFIG.adaptiveEnabled = on;
                            MatrikMod.CONFIG.save();
                            ctx.getSource().sendFeedback(Text.literal("Matrik tự động: " + (on ? "BẬT" : "TẮT")));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("target")
                        .then(ClientCommandManager.argument("fps", IntegerArgumentType.integer(20, 240)).executes(ctx -> {
                            MatrikMod.CONFIG.targetFps = IntegerArgumentType.getInteger(ctx, "fps");
                            MatrikMod.CONFIG.save();
                            ctx.getSource().sendFeedback(Text.literal("FPS mục tiêu: " + MatrikMod.CONFIG.targetFps));
                            return 1;
                        })))
                .then(ClientCommandManager.literal("mode")
                        .then(modeLiteral("nhe", 0))
                        .then(modeLiteral("thuong", 1))
                        .then(modeLiteral("mayyeu", 2)))
                .then(ClientCommandManager.literal("preset")
                        .then(presetLiteral("low"))
                        .then(presetLiteral("balanced"))
                        .then(presetLiteral("high"))));
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<FabricClientCommandSource> modeLiteral(String name, int mode) {
        return ClientCommandManager.literal(name).executes(ctx -> {
            MatrikMod.CONFIG.aggression = mode;
            MatrikMod.CONFIG.save();
            ctx.getSource().sendFeedback(Text.literal("Chế độ: " + name + " (có hiệu lực khi vào thế giới lần sau)"));
            return 1;
        });
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<FabricClientCommandSource> presetLiteral(String name) {
        return ClientCommandManager.literal(name).executes(ctx -> {
            boolean ok = Presets.apply(ctx.getSource().getClient(), name);
            ctx.getSource().sendFeedback(Text.literal(ok ? "Đã áp dụng preset: " + name : "Preset không tồn tại"));
            return ok ? 1 : 0;
        });
    }
}
